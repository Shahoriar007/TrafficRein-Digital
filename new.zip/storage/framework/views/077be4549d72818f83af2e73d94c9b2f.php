<!DOCTYPE html>
<html lang="zxx">
    <head>
        <!-- Meta Tags -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
        <meta name="description" content="Mrittik is a Modern Architecture Theme">
        <meta name="author" content="">

        <!-- Favicon and touch Icons -->
        <link href="../assets/img/favicon.png" rel="shortcut icon" type="image/png">
        <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">
        <link href="../assets/img/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
        <link href="../assets/img/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
        <link href="../assets/img/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

        <!-- Page Title -->
        <title>Mrittik  - Modern Architecture Theme</title>    
        
        <!-- Styles Include -->
        <link rel="stylesheet" href="../assets/css/style.css">
        
    </head>


    <body class="bg-dark">
        

        <!-- Preloader -->
        <div id="preloader">
			<div class="preloader-inner">
				<div class="spinner"></div>
				<div class="loading-text">
					<span data-preloader-text="M" class="characters">M</span>
					
					<span data-preloader-text="R" class="characters">R</span>
					
					<span data-preloader-text="I" class="characters">I</span>
					
					<span data-preloader-text="T" class="characters">T</span>
					
					<span data-preloader-text="T" class="characters">T</span>

					<span data-preloader-text="I" class="characters">I</span>

					<span data-preloader-text="K" class="characters">K</span>
				</div>
			</div>
		</div>

        

        <!-- Color Mode Switcher -->
		<div id="mode_switcher">
			<span><i class="bi bi-moon-fill"></i></span>	
		</div>        

        <!-- Cursor Effect -->
        <div class="pointer bnz-pointer" id="bnz-pointer"></div>

        <!-- Header -->
		<header class="header">				
            <div class="container">
                <div class="header_inner d-flex align-items-center justify-content-between">
                    <div class="logo">
                        <a href="index.html" class="light_logo"><img src="../assets/img/logo-light.svg" alt="logo"></a>
                        <a href="index.html" class="dark_logo"><img src="../assets/img/logo-dark.svg" alt="logo"></a>
                    </div>

                    
                    <div class="mainnav d-none d-lg-block">
                        <ul class="main_menu">
                            <li class="menu-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>

                            <li class="menu-item"><a href="<?php echo e(route('about')); ?>">About</a></li>
                            
                            <li class="menu-item menu-item-has-children"><a href="<?php echo e(route('services')); ?>">Services</a>
                                <ul class="sub-menu">
                                <li class="menu-item"><a href="<?php echo e(route('digital_marketing')); ?>">Digital Marketing</a></li>
                                    <li class="menu-item"><a href="<?php echo e(route('web_development')); ?>">Web Development</a></li>
                                    <li class="menu-item"><a href="project-3.html">Highly Engaging Content & Copy writing</a></li>
                                    <li class="menu-item"><a href="project-details.html">Enterprise Software Development</a></li>
                                    <li class="menu-item"><a href="project-details-2.html">Search Engine Optimisation (SEO)</a></li>
                                    <li class="menu-item"><a href="project-details-2.html">Social Media Marketing & Management</a></li>
                                </ul>
                            </li>
                            <!-- <li class="menu-item menu-item-has-children active"><a href="#">Pages</a>
                                <ul class="sub-menu">
                                    <li class="menu-item active"><a href="about.html">About Us</a></li>
                                    <li class="menu-item menu-item-has-children"><a href="#">Team</a>
                                        <ul class="sub-menu">
                                            <li class="menu-item"><a href="team.html">Our Team</a></li>
                                            <li class="menu-item"><a href="team-details.html">Team Details</a></li>
                                        </ul>
                                    </li>
                                    <li class="menu-item menu-item-has-children"><a href="#">Services</a>
                                        <ul class="sub-menu">
                                            <li class="menu-item"><a href="service-1.html">Service One</a></li>
                                            <li class="menu-item"><a href="service-2.html">Service Two</a></li>
                                            <li class="menu-item"><a href="service-details-DigitalMarketing.html">Service Details Digital Marketing</a></li>
                                        </ul>
                                    </li>                              
                                    <li class="menu-item menu-item-has-children"><a href="#">Shop</a>
                                        <ul class="sub-menu">
                                            <li class="menu-item"><a href="shop-1.html">Shop One</a></li>
                                            <li class="menu-item"><a href="shop-2.html">Shop Two</a></li>
                                            <li class="menu-item"><a href="shop-3.html">Shop Three</a></li>
                                            <li class="menu-item"><a href="shop-product.html">Product Details</a></li>
                                            <li class="menu-item"><a href="shop-cart.html">Shop Cart</a></li>
                                            <li class="menu-item"><a href="shop-checkout.html">Checkout</a></li>
                                            <li class="menu-item"><a href="login.html">Login</a></li>
                                        </ul>
                                    </li>
                                    <li class="menu-item"><a href="404.html">404 Page</a></li>
                                    <li class="menu-item"><a href="coming-soon.html">Coming Soon</a></li>
                                </ul>
                            </li> -->
                            <li class="menu-item"><a href="<?php echo e(route('services')); ?>">Services</a></li>
                            <li class="menu-item"><a href="<?php echo e(route('contact')); ?>">Contacts</a></li>
                            <!-- <li class="menu-item menu-item-has-children"><a href="#">Blog</a>
                                <ul class="sub-menu">
                                    <li class="menu-item"><a href="blog.html">Blog</a></li>
                                    <li class="menu-item"><a href="blog-details.html">Blog Details</a></li>
                                </ul>
                            </li> -->
                        </ul>
                    </div>
                    <div class="header_right_part d-flex align-items-center">
                        <button class="aside_open">
                            <span class="line"></span>
                            <span class="line"></span>
                            <span class="line"></span>
                        </button>
                        <div class="header_search">								
                            <button type="submit" class="form-control-submit"><i class="bi bi-search"></i></button>
                        </div>
                        <div class="open_search">
                            <form class="search_form" action="search.php">
                                <input type="text" name="search" class="keyword form-control" placeholder="Search...">
                                <button type="submit" class="form-control-submit"><i class="bi bi-search"></i></button>
                            </form>
                        </div>							
                        <button class="ma5menu__toggle d-lg-none d-block" type="button">
                            <i class="bi bi-list"></i>
                        </button>
                    </div>
                </div>
			</div>
		</header>

        <div class="aside_info_wrapper">
			<button class="aside_close"><i class="bi bi-x-lg"></i></button>
			<div class="aside_logo">
                <a href="index.html" class="light_logo"><img src="../assets/img/logo-light-lg.svg" alt="logo"></a>
                <a href="index.html" class="dark_logo"><img src="../assets/img/logo-dark-lg.svg" alt="logo"></a>
            </div>
			<div class="aside_info_inner">
                <p>Mrittik Architects is a full-service design firm providing architecture architecture.</p>
                
                <div class="aside_info_inner_box">
                    <h5>Contact Info</h5>
                    <p>+123 456 789 33</p>
                    <p>3 Madison Street, NY <br> United States of America</p>
                    <p>mrittikarch@gmail.com</p>

                    <h5>Office Address</h5>
                    <p>+Time Square, New York <br> USA, 3454</p>
                </div>
                <div class="social_sites">
                    <ul class="d-flex align-items-center justify-content-center">
                        <li><a href="#"><i class="bi bi-facebook"></i></a></li>
                        <li><a href="#"><i class="bi bi-twitter"></i></a></li>
                        <li><a href="#"><i class="bi bi-instagram"></i></a></li>
                        <li><a href="#"><i class="bi bi-youtube"></i></a></li>
                    </ul>
                </div>
			</div>
		</div>

		<!-- Page Header -->
        <div class="page_header">
            <div class="page_header_inner">
                <div class="container">
                    <div class="page_header_content d-flex align-items-center justify-content-between">
                        <h2 class="heading">Contact</h2>
                        <ul class="breadcrumb d-flex align-items-center">
                            <li><a href="index.html">Home</a></li>
                            <li class="active">Contact</li>
                        </ul>
                    </div>
                </div>
            </div>        
        </div>

        
        <!-- Main Wrapper-->
        <main class="wrapper">

            <section class="contact_us bg-dark-200">
                <div class="container">
                    <div class="row justify-content-between">
                        <div class="col-lg-5" data-aos="fade-right" data-aos-duration="1000">
                            <div class="section-header">
                                <h1 class="text-white text-uppercase mb-4">LET’S DISCUSS NEXT PROJECTS</h1>
                                <p class="$gray-600">The talent at Mrittik runs wide and deep. Across many markets, geographies and typologies, our team members are some of the finest professionals in the industry.. We’ve grouped our work into five categories: places, venues, spaces, experiences and events.</p>
                            </div>
                        </div>
                        <div class="col-lg-6" data-aos="fade-left" data-aos-duration="1000">
                            <div class="home_contact">
                                <form action="contact.php" method="POST">
                                    <input class="form-control form-control-lg" name="name" id="name" type="text" placeholder="Your Name*" required="" aria-label=".form-control-lg example">
                                    <input class="form-control form-control-lg" name="phone" id="phone" type="number" placeholder="Your Phone No" aria-label=".form-control-lg example">
                                    <input class="form-control form-control-lg" name="email" id="email" type="email" placeholder="Your Email*" required="" aria-label=".form-control-lg example">
                                    <textarea class="form-control pt-4" name="message" id="message" placeholder="Your Message" rows="3"></textarea>
                                    <div class="btn_group">
                                        <button type="submit" class="btn olive">Send Mail</button>  
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Section Grid Lines -->
                <ul class="grid_lines d-none d-md-flex justify-content-between">
                    <li class="grid_line"></li>
                    <li class="grid_line"></li>
                    <li class="grid_line"></li>
                    <li class="grid_line"></li>
                    <li class="grid_line"></li>
                    <li class="grid_line"></li>
                    <li class="grid_line"></li>
                </ul>
            </section>
        </main>

        <!-- Footer-->
        <footer class="footer bg-dark-200 box_padding">
            <div class="footer_inner bg-black" data-aos="zoom-in" data-aos-duration="1000">
                <div class="container">
                    <div class="row align-items-end">
                        <div class="col-lg-4 col-md-2 col-sm-2">
                            <div class="section-header" data-aos="fade-right" data-aos-duration="1000">
                                <h2>Contact</h2>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-5 col-sm-5">
                            <div class="communication">
                                <div class="info_body" data-aos="fade-up" data-aos-duration="500">
                                    <h6>Studio Website</h6>
                                    <h5>www.mrittikarchitects.com</h5>
                                </div>
                                <div class="info_body" data-aos="fade-up" data-aos-duration="700">
                                    <h6>Email Address</h6>
                                    <h5>mrittikarchitects@gmail.com</h5>
                                </div>
                                <div class="info_body" data-aos="fade-up" data-aos-duration="900">
                                    <h6>Phone No</h6>
                                    <h5>+123 (456789)</h5>
                                </div>
                                <div class="info_body" data-aos="fade-up" data-aos-duration="1100">
                                    <h6>Office Address</h6>
                                    <h5>3 Madison Street NY, USA</h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-5 col-sm-5">
                            <div class="footer_elements d-flex align-items-center justify-content-end">
                                <div class="footer_elements_inner">
                                    <div class="footer_logo" data-aos="fade-up" data-aos-duration="500">
                                        <a href="index.html" class="light_logo"><img src="../assets/img/logo-light.svg" alt="logo"></a>
                                    </div>
                                    <div class="footer_social">
                                        <ul class="social_list">
                                            <li class="facebook" data-aos="fade-up" data-aos-duration="500"><a href="#"><i class="bi bi-facebook"></i></a></li>
                                            <li class="twitter" data-aos="fade-up" data-aos-duration="700"><a href="#"><i class="bi bi-twitter"></i></a></li>
                                            <li class="instagram" data-aos="fade-up" data-aos-duration="900"><a href="#"><i class="bi bi-instagram"></i></a></li>
                                            <li class="youbetube" data-aos="fade-up" data-aos-duration="1100"><a href="#"><i class="bi bi-youtube"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="terms_condition">
                                        <ul>
                                            <li data-aos="fade-up" data-aos-duration="1300"><a href="#">Terms</a></li>
                                            <li data-aos="fade-up" data-aos-duration="1500"><a href="#">Condition</a></li>
                                            <li data-aos="fade-up" data-aos-duration="1700"><a href="#">Policy</a></li>
                                        </ul>
                                    </div>
                                    <div class="copyright" data-aos="fade-up" data-aos-duration="2000">
                                        <p>Mrittik 2023. All Rights Reserved</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                

                <!-- Section Grid Lines -->
                <ul class="grid_lines d-none d-md-flex justify-content-between">
                    <li class="grid_line"></li>
                    <li class="grid_line"></li>
                    <li class="grid_line"></li>
                    <li class="grid_line"></li>
                    <li class="grid_line"></li>
                    <li class="grid_line"></li>
                    <li class="grid_line"></li>
                </ul>
            </div>
        </footer>

        <div class="totop">
            <a href="#">UP</a>
        </div>

        <!-- Page Grid Lines -->
        <ul class="grid_lines d-none d-md-flex justify-content-between">
            <li class="grid_line"></li>
            <li class="grid_line"></li>
            <li class="grid_line"></li>
            <li class="grid_line"></li>
            <li class="grid_line"></li>
            <li class="grid_line"></li>
            <li class="grid_line"></li>
        </ul>

        <!-- Core JS -->
        <script src="../assets/js/jquery-3.6.0.min.js"></script>
        <script src="../assets/js/bootstrap.bundle.min.js"></script>

        <!-- Side Menu -->
        <script src="../plugins/menu/ma5-menu.min.js"></script>
        
        <!-- Swiper for Slider Type -->
        <script src="../plugins/swiper/swiper-bundle.min.js"></script>
        
        

        <!-- Cursor Effect -->
        <script src="../plugins/cursor-effect/cursor-effect.js"></script>
        
        <!-- Select2 -->
        <script src="../plugins/select2/js/select2.min.js"></script>
        
        <!-- AOS effect JS -->
        <script src="../plugins/aos/aos.js"></script>
        
        <!-- Theme Custom JS -->
        <script src="../assets/js/theme.js"></script>
        
        <!-- Google Map Calling -->
	    <script src="../assets/js/map.js"></script>
        <script src="../../../../../maps/api/js?key=AIzaSyCUiaBC-cJ0wcEtqCUtoXF3I91o9wS42gQ"></script>
    </body>
</html><?php /**PATH C:\Users\Public\TrafficreinUK\TrafficRein website\TrafficRein-New-website\TrafficRein-Digital\resources\views/contact.blade.php ENDPATH**/ ?>